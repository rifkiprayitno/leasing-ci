We would like to thank everyone who contributed to this library. If you find our library useful and wish to support as well, you can do so [through Patreon](https://www.patreon.com/limonte) or directly [through PayPal](https://www.paypal.me/limonte/5eur). Your contribution will be greatly appreciated!


# Copper Backers ($5 or more per month)

- **[Malik Nazimanov](https://www.patreon.com/lantos)** ($5 per month)
